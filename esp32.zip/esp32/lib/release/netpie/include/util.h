#include <string.h>

#define LED_WIFI_GPIO 2
#define LED_NTP_GPIO 15
#define LED_IOT_GPIO 12
#define LED_ON 0
#define LED_OFF 1

int strxcpy(char *dest, char *src, int max);
