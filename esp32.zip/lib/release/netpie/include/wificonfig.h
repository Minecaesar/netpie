#ifndef wificonfig_h
#define wificonfig_h

// #define CONFIG_WIFI_SSID "PiLand"
// #define CONFIG_WIFI_PASSWORD "11112014"

// #define CONFIG_WIFI_SSID "catbus"
// #define CONFIG_WIFI_PASSWORD "stud2559"

#define CONFIG_WIFI_SSID "Dookphoo_2.4G"
#define CONFIG_WIFI_PASSWORD "26072527"


#endif
