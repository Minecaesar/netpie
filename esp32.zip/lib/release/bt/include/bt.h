#pragma once
#warning "This header is deprecated, please use functions defined in esp_bt.h instead."
#include "esp_bt.h"
